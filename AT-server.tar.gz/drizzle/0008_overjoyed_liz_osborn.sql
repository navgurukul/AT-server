ALTER TABLE IF EXISTS "leave_requests" DROP COLUMN IF EXISTS "decided_at";
