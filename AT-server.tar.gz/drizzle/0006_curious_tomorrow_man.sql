ALTER TABLE IF EXISTS "leave_requests" ADD COLUMN IF NOT EXISTS "half_day_segment" varchar(20);
