ALTER TABLE "timesheet_entries" DROP COLUMN "task_title";--> statement-breakpoint
ALTER TABLE "timesheet_entries" DROP COLUMN "tags";