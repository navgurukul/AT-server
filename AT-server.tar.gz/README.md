Clone the repo

Run npm i,

Add the env file,

run npx drizzle-kit generate,
run npx drizzle-kit migrate,
 

run npm run build- should result in no errors,
run npm run dev

 

